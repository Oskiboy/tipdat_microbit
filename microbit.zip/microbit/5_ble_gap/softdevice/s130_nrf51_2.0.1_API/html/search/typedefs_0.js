var searchData=
[
  ['nrf_5ffault_5fhandler_5ft',['nrf_fault_handler_t',['../group__NRF__SDM__TYPES.html#gab1e24001fc18966505cd6358dce4af28',1,'nrf_sdm.h']]],
  ['nrf_5fmutex_5ft',['nrf_mutex_t',['../group__NRF__SOC__STRUCTURES.html#gaa1ec46ac9de000227852834ec1ff86ea',1,'nrf_soc.h']]],
  ['nrf_5fradio_5fsignal_5fcallback_5ft',['nrf_radio_signal_callback_t',['../group__NRF__SOC__STRUCTURES.html#ga6e9caf6855be0c4c4fe348090f551a33',1,'nrf_soc.h']]]
];
