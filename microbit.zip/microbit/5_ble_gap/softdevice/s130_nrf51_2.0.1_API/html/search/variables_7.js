var searchData=
[
  ['gap_5fenable_5fparams',['gap_enable_params',['../structble__enable__params__t.html#ac14566b7abd979db7845a24bf6b11ee4',1,'ble_enable_params_t']]],
  ['gap_5fevt',['gap_evt',['../structble__evt__t.html#a67ca1f9db570d1c2f196c0a316151af5',1,'ble_evt_t']]],
  ['gap_5fopt',['gap_opt',['../unionble__opt__t.html#a389cdb4378d2a7f989807dcf27145051',1,'ble_opt_t']]],
  ['gatt_5fstatus',['gatt_status',['../structble__gattc__evt__t.html#a844b25b255a6a17284b6285baa1fec6f',1,'ble_gattc_evt_t::gatt_status()'],['../structble__gatts__authorize__params__t.html#a22732489c5283481acd5d8c883dd6819',1,'ble_gatts_authorize_params_t::gatt_status()']]],
  ['gattc_5fevt',['gattc_evt',['../structble__evt__t.html#a2bdcb3c197239b4e5957d89bb0f26161',1,'ble_evt_t']]],
  ['gatts_5fenable_5fparams',['gatts_enable_params',['../structble__enable__params__t.html#ad2de18bc975930cadc754c5e3468c870',1,'ble_enable_params_t']]],
  ['gatts_5fevt',['gatts_evt',['../structble__evt__t.html#aea997556a147ad5541998f13699e27c1',1,'ble_evt_t']]],
  ['gpio_5fpin',['gpio_pin',['../structble__pa__lna__cfg__t.html#a98588797b646a5b41102e6b1deb9c8b4',1,'ble_pa_lna_cfg_t']]],
  ['gpiote_5fch_5fid',['gpiote_ch_id',['../structble__common__opt__pa__lna__t.html#a2756839a926a4f2a6203cc2e2fb6b43c',1,'ble_common_opt_pa_lna_t']]]
];
