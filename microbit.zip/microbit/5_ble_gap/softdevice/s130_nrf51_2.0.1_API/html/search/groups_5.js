var searchData=
[
  ['functions',['Functions',['../group__BLE__COMMON__FUNCTIONS.html',1,'']]],
  ['functions',['Functions',['../group__BLE__GAP__FUNCTIONS.html',1,'']]],
  ['functions',['Functions',['../group__BLE__GATTC__FUNCTIONS.html',1,'']]],
  ['functions',['Functions',['../group__BLE__GATTS__FUNCTIONS.html',1,'']]],
  ['functions',['Functions',['../group__BLE__L2CAP__FUNCTIONS.html',1,'']]],
  ['fault_20id_20ranges',['Fault ID ranges',['../group__NRF__FAULT__ID__RANGES.html',1,'']]],
  ['fault_20id_20types',['Fault ID types',['../group__NRF__FAULT__IDS.html',1,'']]],
  ['functions',['Functions',['../group__NRF__MBR__FUNCTIONS.html',1,'']]],
  ['functions',['Functions',['../group__NRF__SDM__FUNCTIONS.html',1,'']]],
  ['functions',['Functions',['../group__NRF__SOC__FUNCTIONS.html',1,'']]]
];
