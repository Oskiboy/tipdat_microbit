var searchData=
[
  ['soc_5fecb_5fciphertext_5ft',['soc_ecb_ciphertext_t',['../group__NRF__SOC__STRUCTURES.html#ga1fe45981ce2f5e859e2c786ae873efa9',1,'nrf_soc.h']]],
  ['soc_5fecb_5fcleartext_5ft',['soc_ecb_cleartext_t',['../group__NRF__SOC__STRUCTURES.html#ga3caff4118ced96100cb3104986981a7f',1,'nrf_soc.h']]],
  ['soc_5fecb_5fkey_5ft',['soc_ecb_key_t',['../group__NRF__SOC__STRUCTURES.html#ga07725f4db351b1db21cf21787d0ee7ea',1,'nrf_soc.h']]]
];
