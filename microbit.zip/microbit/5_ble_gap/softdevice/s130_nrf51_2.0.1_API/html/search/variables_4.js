var searchData=
[
  ['data',['data',['../structble__gap__evt__adv__report__t.html#a460b30b7d1c4bc79194c3a5da4edc91b',1,'ble_gap_evt_adv_report_t::data()'],['../structble__gattc__evt__read__rsp__t.html#adaf3ed862b2c96947da60d9b576b31c9',1,'ble_gattc_evt_read_rsp_t::data()'],['../structble__gattc__evt__write__rsp__t.html#a1691be986d4b730bbe2ccc3d40c5a088',1,'ble_gattc_evt_write_rsp_t::data()'],['../structble__gattc__evt__hvx__t.html#af239b9ba3cff6d1fc678f3f71711a2f3',1,'ble_gattc_evt_hvx_t::data()'],['../structble__gatts__evt__write__t.html#abe4bd839db7c40829ccdbff3d1f79a57',1,'ble_gatts_evt_write_t::data()'],['../structble__l2cap__evt__rx__t.html#ad3df37c1998b3d1d213a6e7b5cfbcd5e',1,'ble_l2cap_evt_rx_t::data()']]],
  ['desc',['desc',['../structble__gatts__char__pf__t.html#a9133fc1220787c07ac21291dab7b8b22',1,'ble_gatts_char_pf_t']]],
  ['desc_5fdisc_5frsp',['desc_disc_rsp',['../structble__gattc__evt__t.html#a23df4ef5d71063a9921c787dbf2dfa85',1,'ble_gattc_evt_t']]],
  ['descs',['descs',['../structble__gattc__evt__desc__disc__rsp__t.html#a3d41c7255fa19fa2b55acd6962be26ee',1,'ble_gattc_evt_desc_disc_rsp_t']]],
  ['disconnected',['disconnected',['../structble__gap__evt__t.html#a2649b3d6849778ddb1abd5addb7d2322',1,'ble_gap_evt_t']]],
  ['distance_5fus',['distance_us',['../structnrf__radio__request__normal__t.html#a34cb59c0e80b3698a3df265ab88b34b5',1,'nrf_radio_request_normal_t']]],
  ['dlen',['dlen',['../structble__gap__evt__adv__report__t.html#aa1cbdc1d8b21b88f2da188d6eda04f1d',1,'ble_gap_evt_adv_report_t']]],
  ['dst',['dst',['../structsd__mbr__command__copy__sd__t.html#ae8afbb5ddb539bf7d5aa63102313210a',1,'sd_mbr_command_copy_sd_t']]]
];
