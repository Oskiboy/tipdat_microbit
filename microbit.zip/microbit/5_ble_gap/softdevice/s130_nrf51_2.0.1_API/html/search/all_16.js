var searchData=
[
  ['xtal_5faccuracy',['xtal_accuracy',['../structnrf__clock__lf__cfg__t.html#a540f620c8593921705c74c14f3f725f1',1,'nrf_clock_lf_cfg_t']]]
];
