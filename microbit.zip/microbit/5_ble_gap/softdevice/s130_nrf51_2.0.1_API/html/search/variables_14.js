var searchData=
[
  ['value_5fhandle',['value_handle',['../structble__gatts__char__handles__t.html#a685865a59e73158fd661e9d64407e9d9',1,'ble_gatts_char_handles_t']]],
  ['value_5flen',['value_len',['../structble__gattc__evt__char__val__by__uuid__read__rsp__t.html#a91e554093e8f445960abff9c0015193c',1,'ble_gattc_evt_char_val_by_uuid_read_rsp_t']]],
  ['values',['values',['../structble__gattc__evt__char__vals__read__rsp__t.html#ac586dcb02b8f378127157ee8c45abea9',1,'ble_gattc_evt_char_vals_read_rsp_t']]],
  ['version_5fnumber',['version_number',['../structble__version__t.html#af18ca1a9b3d80b05042d9121e9d3c9ed',1,'ble_version_t']]],
  ['vlen',['vlen',['../structble__gatts__attr__md__t.html#a921e414734cd784e0c3b7309d3a14f39',1,'ble_gatts_attr_md_t']]],
  ['vloc',['vloc',['../structble__gatts__attr__md__t.html#abbd6b9b2d75565fc6fd66074a47308c7',1,'ble_gatts_attr_md_t']]],
  ['vs_5fuuid_5fcount',['vs_uuid_count',['../structble__common__enable__params__t.html#afba280d9af779389b8456889f6e16eb6',1,'ble_common_enable_params_t']]]
];
