var searchData=
[
  ['attribute_20information_20formats',['Attribute Information Formats',['../group__BLE__GATTC__ATTR__INFO__FORMAT.html',1,'']]],
  ['attribute_20table_20size',['Attribute Table size',['../group__BLE__GATTS__ATTR__TAB__SIZE.html',1,'']]],
  ['assigned_20values_20for_20ble_20uuids',['Assigned Values for BLE UUIDs',['../group__BLE__UUID__VALUES.html',1,'']]]
];
