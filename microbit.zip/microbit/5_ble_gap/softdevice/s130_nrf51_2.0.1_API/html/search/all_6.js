var searchData=
[
  ['functions',['Functions',['../group__BLE__COMMON__FUNCTIONS.html',1,'']]],
  ['functions',['Functions',['../group__BLE__GAP__FUNCTIONS.html',1,'']]],
  ['functions',['Functions',['../group__BLE__GATTC__FUNCTIONS.html',1,'']]],
  ['functions',['Functions',['../group__BLE__GATTS__FUNCTIONS.html',1,'']]],
  ['functions',['Functions',['../group__BLE__L2CAP__FUNCTIONS.html',1,'']]],
  ['flags',['flags',['../structble__gattc__write__params__t.html#ae9bf42dc0e530824c93ec423e6539220',1,'ble_gattc_write_params_t']]],
  ['format',['format',['../structble__gattc__evt__attr__info__disc__rsp__t.html#ab9e38c0784b5be6d9bd3f5f301239bf6',1,'ble_gattc_evt_attr_info_disc_rsp_t::format()'],['../structble__gatts__char__pf__t.html#a9a79d570aa8f758c81ddddbf345b289e',1,'ble_gatts_char_pf_t::format()']]],
  ['fp',['fp',['../structble__gap__adv__params__t.html#a9e2d44610c896a2d1466eb293688f226',1,'ble_gap_adv_params_t']]],
  ['fault_20id_20ranges',['Fault ID ranges',['../group__NRF__FAULT__ID__RANGES.html',1,'']]],
  ['fault_20id_20types',['Fault ID types',['../group__NRF__FAULT__IDS.html',1,'']]],
  ['functions',['Functions',['../group__NRF__MBR__FUNCTIONS.html',1,'']]],
  ['functions',['Functions',['../group__NRF__SDM__FUNCTIONS.html',1,'']]],
  ['functions',['Functions',['../group__NRF__SOC__FUNCTIONS.html',1,'']]]
];
