#ifndef UBIT_BUTTON_H
#define UBIT_BUTTON_H

void ubit_button_init();

int ubit_button_press_a();

int ubit_button_press_b();

#endif
